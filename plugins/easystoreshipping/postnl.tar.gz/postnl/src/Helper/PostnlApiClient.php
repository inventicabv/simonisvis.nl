<?php
/**
 * @package     EasyStore.Site
 * @subpackage  EasyStoreShipping.postnl
 *
 * @copyright   Copyright (C) 2025. All rights reserved.
 * @license     GNU General Public License version 3; see LICENSE
 */

namespace JoomShaper\Plugin\EasyStoreShipping\Postnl\Helper;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

/**
 * PostNL API Client Helper Class
 *
 * This is a basic implementation. You can integrate the official PostNL SDK here.
 * For now, it provides mock data for development purposes.
 *
 * @since 1.0.0
 */
class PostnlApiClient
{
    private $baseUrl;
    private $apiKey;
    private $curl;

    /**
     * Constructor
     *
     * @param string $apiKey  The API key for PostNL
     * @param string $baseUrl The base URL for PostNL API
     *
     * @since 1.0.0
     */
    public function __construct($apiKey = 'demo-key', $baseUrl = 'https://api-mock.postnl.nl/v1/calculate/price/delivery')
    {
        $this->baseUrl = $baseUrl;
        $this->apiKey  = $apiKey;
        $this->curl    = curl_init();
        $this->setDefaultCurlOptions();
    }

    /**
     * Destructor
     *
     * @since 1.0.0
     */
    public function __destruct()
    {
        if ($this->curl) {
            curl_close($this->curl);
        }
    }

    /**
     * Set default cURL options
     *
     * @return void
     *
     * @since 1.0.0
     */
    private function setDefaultCurlOptions(): void
    {
        curl_setopt_array($this->curl, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING       => '',
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST  => 'POST',
            CURLOPT_HTTPHEADER     => $this->getDefaultHeaders(),
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
    }

    /**
     * Get default headers for API requests
     *
     * @return array
     *
     * @since 1.0.0
     */
    private function getDefaultHeaders(): array
    {
        return [
            'apikey: ' . $this->apiKey,
            'Accept: application/json',
            'Content-Type: application/json',
        ];
    }

    /**
     * Update API credentials
     *
     * @param string $apiKey The new API key
     *
     * @return void
     *
     * @since 1.0.0
     */
    public function updateCredentials(string $apiKey): void
    {
        $this->apiKey = $apiKey;
        curl_setopt($this->curl, CURLOPT_HTTPHEADER, $this->getDefaultHeaders());
    }

    /**
     * Get shipping rates from PostNL API
     *
     * This is a placeholder implementation.
     * TODO: Integrate with official PostNL SDK when available
     *
     * @param array $params Query parameters for the API call
     *
     * @return array Decoded JSON response
     *
     * @since 1.0.0
     */
    public function getShippingRates(array $params): array
    {
        // For mock environment, return sample data
        if ($this->apiKey === 'demo-key') {
            return $this->getMockShippingRates($params);
        }

        try {
            $this->validateShippingParams($params);

            // Build request body for PostNL API
            $requestBody = $this->buildRequestBody($params);

            curl_setopt($this->curl, CURLOPT_URL, $this->baseUrl);
            curl_setopt($this->curl, CURLOPT_POSTFIELDS, json_encode($requestBody));

            $response = curl_exec($this->curl);

            if ($response === false) {
                throw new \Exception('cURL error: ' . curl_error($this->curl));
            }

            $httpCode = curl_getinfo($this->curl, CURLINFO_HTTP_CODE);
            if ($httpCode >= 400) {
                $errorMessage = $this->parseErrorResponse($response, $httpCode);
                throw new \Exception('HTTP error: ' . $httpCode . ' - ' . $errorMessage);
            }

            $decodedResponse = json_decode($response, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new \Exception('JSON decode error: ' . json_last_error_msg());
            }

            return $decodedResponse;

        } catch (\Exception $e) {
            // Log error and return empty array
            error_log('PostNL API Error: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Build request body for PostNL API
     *
     * @param array $params The request parameters
     *
     * @return array The formatted request body
     *
     * @since 1.0.0
     */
    private function buildRequestBody(array $params): array
    {
        // TODO: Format this according to PostNL SDK documentation
        // This is a basic structure that may need adjustment
        return [
            'CustomerCode'   => $params['customerCode'] ?? '',
            'CustomerNumber' => $params['customerNumber'] ?? '',
            'Shipment'       => [
                'DeliveryAddress' => [
                    'CountryCode' => $params['destinationCountryCode'] ?? '',
                    'PostalCode'  => $params['destinationPostalCode'] ?? '',
                    'City'        => $params['destinationCity'] ?? '',
                ],
                'Dimension' => [
                    'Weight' => $params['weight'] ?? 0,
                    'Length' => $params['length'] ?? 0,
                    'Width'  => $params['width'] ?? 0,
                    'Height' => $params['height'] ?? 0,
                ],
                'ShippingDate' => $params['shippingDate'] ?? date('d-m-Y'),
            ],
        ];
    }

    /**
     * Validate required parameters for shipping rates
     *
     * @param array $params The parameters to validate
     *
     * @return void
     *
     * @throws \Exception If required parameters are missing
     *
     * @since 1.0.0
     */
    private function validateShippingParams(array $params): void
    {
        $requiredParams = ['customerCode', 'customerNumber', 'destinationCountryCode', 'destinationPostalCode'];

        foreach ($requiredParams as $param) {
            if (!isset($params[$param]) || empty($params[$param])) {
                throw new \Exception("Required parameter '{$param}' is missing or empty");
            }
        }
    }

    /**
     * Parse error response to get meaningful error message
     *
     * @param string $response The error response
     * @param int    $httpCode The HTTP status code
     *
     * @return string The error message
     *
     * @since 1.0.0
     */
    private function parseErrorResponse(string $response, int $httpCode): string
    {
        $decodedError = json_decode($response, true);

        if (json_last_error() === JSON_ERROR_NONE && isset($decodedError['message'])) {
            return $decodedError['message'];
        }

        return $response ?: 'Unknown error occurred';
    }

    /**
     * Get mock shipping rates for development/testing
     *
     * @param array $params The request parameters
     *
     * @return array Mock shipping rates
     *
     * @since 1.0.0
     */
    private function getMockShippingRates(array $params): array
    {
        // Return sample PostNL shipping options
        return [
            'products' => [
                [
                    'productName'           => 'Standard Delivery',
                    'price'                 => 6.95,
                    'estimatedDeliveryDate' => date('Y-m-d', strtotime('+2 days')),
                    'productCode'           => '3085',
                ],
                [
                    'productName'           => 'Evening Delivery',
                    'price'                 => 8.95,
                    'estimatedDeliveryDate' => date('Y-m-d', strtotime('+1 day')),
                    'productCode'           => '3089',
                ],
                [
                    'productName'           => 'Next Day Delivery',
                    'price'                 => 12.95,
                    'estimatedDeliveryDate' => date('Y-m-d', strtotime('+1 day')),
                    'productCode'           => '3087',
                ],
            ],
        ];
    }
}
